# Student Hustle — iPhone Home Screen

1. Put these files on a web host that supports HTTPS (required by iPhone for installable web apps/service workers).
2. Open the hosted `index.html` in Safari.
3. Tap Share → Add to Home Screen.
4. Tap Add.

The app can then open like a normal Home Screen app and keep its local data.
